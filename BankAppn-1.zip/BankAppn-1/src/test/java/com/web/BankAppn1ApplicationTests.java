package com.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
