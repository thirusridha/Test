package com.web.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.web.Repo.BankRepo;
import com.web.Service.BankIn;
import com.web.entity.Bank;

@RestController
public class Bankcontroller {
	@Autowired 
	private BankRepo bankRepo;
	@Autowired
	private BankIn b1;
	@PostMapping("/reg")
	public String saveDetails(@RequestBody Bank b) {
		return b1.regform(b);
	
	}
	@GetMapping("/balanceform")
	public String showDetails(@RequestBody Bank b) {
		
		return b1.Balanceform(b);
	}
	@PatchMapping("/deposit")
	public String depositform(@RequestBody Bank b) {
		
		return b1.DepositeForm(b);
	}
	@PatchMapping("/withdraw")
	public String withdrawform(@RequestBody Bank b) {
		
		return b1.WithDrawForm(b);
	}
	@PatchMapping("/transfer")
	public String transferform(@RequestBody Bank b) {
		return b1.Transfer(b);
	}
	@PostMapping("/delete/{ano}")
	public String deleteAccount(@PathVariable long ano ) {
		return b1.deleteAccount(ano);
	}
	@GetMapping("/getAll")
	public List<Bank> getAll(){
		List<Bank> bankList= bankRepo.findAll();
		return bankList;
		
	}
	@PostMapping("/delete2/{ano}")
	public String deleteAccount1(@PathVariable long ano) {
		
		bankRepo.deleteById(ano);
		return ano+" is deleted successfully...";
	}


	
}
