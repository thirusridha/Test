package com.web.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.Repo.BankRepo;
import com.web.entity.Bank;
@Service
public class BankImp implements BankIn {
	
	@Autowired
	private BankRepo brepo;

	@Override
	public String regform(Bank b) {
		String message="";
		if(b.getPassword().equals(b.getConfirmpass())) {
			brepo.save(b);
			message ="Registered successfully...!";
		}else {
			message =" fail password does'nt match...!";
		}
		
		return message;
	}

	@Override
	public String Balanceform(Bank b) {
		String message="";
		Bank b1=brepo.findById(b.getano()).get();
		if(b.getano()==(b1.getano())&&b.getName().equals(b1.getName())&&b.getPassword().equals(b1.getPassword())){
			message= "Name:"+b.getName()+" "+"amount:"+b1.getAmount();
		}
		else {
			message= "name and password doesn't match...!";
		}
		return message;

	}

	@Override
	public String DepositeForm(Bank b) {
		String message="";
		Bank b1=brepo.findById(b.getano()).get();
		if(b.getano()==(b1.getano())&&b.getName().equals(b1.getName())&&b.getPassword().equals(b1.getPassword())  )
		{
			b1.setAmount(b.getAmount()+b1.getAmount());
			brepo.save(b1);
			 message=" previous balance: "+(b1.getAmount()+b.getAmount())+" affter depositing of "+b.getAmount()+" current total: "+((b1.getAmount()));
		}
		else {
			message="password and name doesn't match";
		}
		return message;

	}

	@Override
	public String WithDrawForm(Bank b) {
		String message="";
		Bank b1 = brepo.findById(b.getano()).get();
		if(b.getano()==(b1.getano())&&(b.getName().equals(b1.getName())&&(b.getPassword().equals(b1.getPassword()))))
		{
			b1.setAmount(b1.getAmount()-b.getAmount());
			brepo.save(b1);
			message=" before money:"+(b1.getAmount()-b.getAmount())+" after withdraw of :"+b.getAmount()+" current balance is: "+(b1.getAmount());
			
		}
		else {
			message="password and name doesn't match!";
			
		}
		return message;

	}

	@Override
	public String Transfer(Bank b) {
		Bank b1=brepo.findById(b.getano()).get();
		String message="";
		
		
		if(b.getano()==(b1.getano())&&(b.getName().equals(b1.getName())&&(b.getPassword().equals(b1.getPassword()))))
		{
			
			b1.setAmount(b1.getAmount()+b.getAmount());
			brepo.save(b1);
			
			
			message=" before transfer amt:"+(b1.getAmount()-b.getAmount())+ "after transfer of :"+b.getAmount()+" final amt is "+b1.getAmount();
		}
		return message;

	}
	@Override
	public String deleteAccount(long ano) {
		brepo.deleteById(ano);
		brepo.deleteById(ano);
		return ano+" is deleted successfully...";
	}

	@Override
	public String closeAccount(Bank b) {
		// TODO Auto-generated method stub
		return null;
	}

}
