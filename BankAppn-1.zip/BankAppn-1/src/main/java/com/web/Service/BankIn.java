package com.web.Service;

import java.util.List;

import com.web.entity.Bank;

public interface BankIn {
	public String regform(Bank b);
	public String Balanceform(Bank b);
	public String DepositeForm(Bank b);
	public String WithDrawForm(Bank b);
	public String Transfer(Bank b);
	public String closeAccount(Bank b);
	public String deleteAccount(long ano);
}
