package com.web.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bankinfo")
public class Bank {
	@Id
	private long ano;
	private String name;
	private String password;
	private String confirmpass;
	private double amount;
	private String address;
	private long moblie;

	@Override
	public String toString() {
		return "Bank [ano=" + ano + ", name=" + name + ", password=" + password + ", confirmpass=" + confirmpass
				+ ", amount=" + amount + ", address=" + address + ", moblie=" + moblie + "]";
	}

	public Bank(long ano, String name, String password, String confirmpass, double amount, String address,
			long moblie) {
		super();
		this.ano = ano;
		this.name = name;
		this.password = password;
		this.confirmpass = confirmpass;
		this.amount = amount;
		this.address = address;
		this.moblie = moblie;
	}

	public Bank() {
		super();
	}

	public long getano() {
		return ano;
	}

	public void setano(long ano) {
		this.ano = ano;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmpass() {
		return confirmpass;
	}

	public void setConfirmpass(String confirmpass) {
		this.confirmpass = confirmpass;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getMoblie() {
		return moblie;
	}

	public void setMoblie(long moblie) {
		this.moblie = moblie;
	}

}
